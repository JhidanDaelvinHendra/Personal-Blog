<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Perawatan Hewan</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center; /* Mengatur agar konten di tengah horizontal */
            align-items: center; /* Mengatur agar konten di tengah vertikal */
            height: 100vh; /* Menggunakan tinggi 100% viewport untuk konten di tengah */
        }
        .container {
            max-width: 1200px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center; /* Mengatur agar teks berada di tengah */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #f2f2f2;
        }
        .filter-form {
            margin-bottom: 20px;
        }
        .filter-form input[type="text"] {
            padding: 10px;
            width: calc(100% - 22px);
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .filter-form input[type="submit"] {
            padding: 10px 20px;
            border: none;
            background-color: #333;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Dashboard Perawatan Hewan</h2>
    <form class="filter-form" method="GET" action="">
        <input type="text" name="keyword" placeholder="Masukkan keyword...">
        <input type="submit" value="Filter">
    </form>

    <?php
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'sisteminformasimanajemenrumahsakithewan';

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

    $sql = "SELECT ID_Rekam_Medis, ID_Hewan, ID_Dokter, Diagnosa, Tanggal_Kunjungan FROM rekam_medis WHERE ID_Rekam_Medis LIKE '%$keyword%' OR ID_Hewan LIKE '%$keyword%' OR ID_Dokter LIKE '%$keyword%' OR Diagnosa LIKE '%$keyword%' OR Tanggal_Kunjungan LIKE '%$keyword%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>ID Rekam Medis</th><th>ID Hewan</th><th>ID Dokter</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["ID_Rekam_Medis"] . "</td>";
            echo "<td>" . $row["ID_Hewan"] . "</td>";
            echo "<td>" . $row["ID_Dokter"] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>Tidak ada data rekam medis ditemukan.</p>";
    }

    $conn->close();
    ?>

</div>

</body>
</html>
