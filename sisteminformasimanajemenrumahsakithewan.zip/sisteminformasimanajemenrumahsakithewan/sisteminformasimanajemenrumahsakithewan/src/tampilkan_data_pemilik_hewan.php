<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Data Pemilik Hewan</title>
<link rel="stylesheet" href="hewan.css">
<style>

    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f0f0f0;
        margin: 0;
        padding: 20px;
    }

    .form-container {
        max-width: 800px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table th, table td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: left;
    }

    table th {
        background-color: #f2f2f2;
    }

    @media (max-width: 768px) {
        table {
            overflow-x: auto;
            display: block;
        }
        table th, table td {
            white-space: nowrap;
        }
    }

    .filter-form {
        margin-bottom: 20px;
    }

    .filter-form input[type="text"] {
        padding: 10px;
        width: calc(100% - 22px);
        margin-right: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .filter-form input[type="submit"] {
        padding: 10px 20px;
        border: none;
        background-color: #333;
        color: #fff;
        border-radius: 4px;
        cursor: pointer;
    }
</style>
</head>
<body>

<div class="form-container">
    <h2>Data Pemilik Hewan</h2>
    <form class="filter-form" method="GET" action="">
        <input type="text" name="keyword" placeholder="Masukkan keyword...">
        <input type="submit" value="Filter">
    </form>

    <?php

    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'sisteminformasimanajemenrumahsakithewan';

    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

    $sql_pemilik = "SELECT ID_Pemilik, Nama_Pemilik, Alamat, Nomor_Telepon, ID_Dokter FROM pemilik_hewan WHERE Nama_Pemilik LIKE '%$keyword%' OR Alamat LIKE '%$keyword%' OR Nomor_Telepon LIKE '%$keyword%' OR ID_Dokter LIKE '%$keyword%'";
    $result_pemilik = $conn->query($sql_pemilik);

    if ($result_pemilik->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>ID Pemilik</th><th>Nama Pemilik</th><th>Alamat</th><th>Nomor Telepon</th><th>ID Dokter</th><th>Aksi</th></tr>";
        
        while($row = $result_pemilik->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row["ID_Pemilik"]."</td>";
            echo "<td>".$row["Nama_Pemilik"]."</td>";
            echo "<td>".$row["Alamat"]."</td>";
            echo "<td>".$row["Nomor_Telepon"]."</td>";
            echo "<td>".$row["ID_Dokter"]."</td>";

            echo "<td><a href='edit_data_pemilik_hewan.php?id=".$row["ID_Pemilik"]."'>Edit</a> | ";

            echo "<a href='delete_data_pemilik_hewan.php?id=".$row["ID_Pemilik"]."'>Delete</a></td>";
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "<p>Tidak ada data pemilik hewan ditemukan.</p>";
    }

    $conn->close();
    ?>  
</div>

</body>
</html>
