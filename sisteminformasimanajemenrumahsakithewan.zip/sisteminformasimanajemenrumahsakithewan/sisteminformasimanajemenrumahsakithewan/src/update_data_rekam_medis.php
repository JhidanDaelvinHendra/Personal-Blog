<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Data Rekam Medis</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        .form-container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center; /* Center content in the form container */
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group select {
            width: calc(100% - 16px);
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #45a049;
        }

        .back-link {
            margin-top: 10px;
            display: inline-block; /* Make the link inline block */
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* Centered paragraph */
        .form-container p {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Update Data Rekam Medis</h2>

    <?php
    // Konfigurasi koneksi database
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'sisteminformasimanajemenrumahsakithewan';

    // Buat koneksi
    $conn = new mysqli($host, $username, $password, $database);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Mengambil data dari form
    $id_rekam_medis = $_POST['id_rekam_medis'];
    $id_hewan = $_POST['id_hewan'];
    $id_dokter = $_POST['id_dokter'];
    $diagnosa = $_POST['diagnosa'];
    $tanggal_kunjungan = $_POST['tanggal_kunjungan'];

    // Query untuk memperbarui data rekam medis
    $sql = "UPDATE rekam_medis SET ID_Hewan = ?, ID_Dokter = ?, Diagnosa = ?, Tanggal_Kunjungan = ? WHERE ID_Rekam_Medis = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $id_hewan, $id_dokter, $diagnosa, $tanggal_kunjungan, $id_rekam_medis);

    // Eksekusi query dan periksa apakah berhasil
    if ($stmt->execute()) {
        echo "<p>Data rekam medis berhasil diperbarui.</p>";
    } else {
        echo "<p>Error: " . $stmt->error . "</p>";
    }

    // Menutup koneksi
    $conn->close();
    ?>

    <!-- Tambahkan link untuk kembali ke halaman utama atau daftar rekam medis -->
    <a class="back-link" href="tampilkan_data_rekam_medis.php">Kembali ke Daftar Rekam Medis</a>
</div>

</body>
</html>
