<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hapus Data Hewan</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        .form-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            margin-top: 20px;
        }

        input[type="submit"] {
            background-color: #e74c3c;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #c0392b;
        }

        .message {
            margin-top: 20px;
            font-weight: bold;
            color: #2ecc71; /* Green color for success message */
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Hapus Data Hewan</h2>
    <form method="GET" action="">
    </form>
    
    <div class="message">
    <?php
    if (isset($_GET['id']) && !empty($_GET['id'])) {
        $id_hewan = $_GET['id'];

        // Database connection details
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'sisteminformasimanajemenrumahsakithewan';

        // Create a new database connection
        $conn = new mysqli($host, $username, $password, $database);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die("Koneksi gagal: " . $conn->connect_error);
        }

        try {
            // SQL query to delete the animal record from the 'hewan' table
            $sql_delete_hewan = "DELETE FROM hewan WHERE ID_Hewan = $id_hewan";

            // Execute the query
            if ($conn->query($sql_delete_hewan) === TRUE) {
                echo "<p>Data hewan berhasil dihapus.</p>";
            }
        } catch (mysqli_sql_exception $e) {
            // In case of an error, do nothing to keep the output clean
        }

        // Close the database connection
        $conn->close();
    }
    ?>
    </div>
</div>

</body>
</html>
