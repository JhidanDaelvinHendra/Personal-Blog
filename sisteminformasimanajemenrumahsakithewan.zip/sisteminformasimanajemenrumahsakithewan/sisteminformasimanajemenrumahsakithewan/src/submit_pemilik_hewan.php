<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pemilik Hewan</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .form-container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .data-table th, .data-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .data-table th {
            background-color: #f2f2f2;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .form-container h3 {
            margin-top: 0;
            text-align: center;
        }
        .form-container a {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #333;
        }
        .form-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h3>Data Pemilik Hewan Berhasil Disimpan</h3>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id_pemilik = $_POST['id_pemilik'];
        $nama_pemilik = $_POST['nama_pemilik'];
        $alamat = $_POST['alamat'];
        $nomor_telepon = $_POST['nomor_telepon'];
        $id_dokter = $_POST['id_dokter'];

        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "sisteminformasimanajemenrumahsakithewan";

        $conn = new mysqli($servername, $username, $password, $database);

        if ($conn->connect_error) {
            die("Koneksi gagal: " . $conn->connect_error);
        }

        $sql = "INSERT INTO pemilik_hewan (ID_Pemilik, Nama_Pemilik, Alamat, Nomor_Telepon, ID_Dokter) 
                VALUES ('$id_pemilik', '$nama_pemilik', '$alamat', '$nomor_telepon', '$id_dokter')";

        if ($conn->query($sql) === TRUE) {

            echo "<table class='data-table'>";
            echo "<tr><th>ID Pemilik</th><th>Nama Pemilik</th><th>Alamat</th><th>Nomor Telepon</th><th>ID Dokter</th></tr>";
            echo "<tr><td>$id_pemilik</td><td>$nama_pemilik</td><td>$alamat</td><td>$nomor_telepon</td><td>$id_dokter</td></tr>";
            echo "</table>";

            echo "<br>";
            echo "<img src='NiawHospitalLogo.png' alt='Niaw Hospital Logo' style='max-width: 200px;'>"; // Sesuaikan ukuran maksimal jika perlu
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    } else {
        echo "<p>Akses tidak sah untuk halaman ini.</p>";
    }
    ?>
    <br><br>
    <a href="dokter_hewan.html">Kembali ke Form Hewan</a>
    <a href="dokter_hewan.html">Kuesioner Dokter Hewan</a> 
</div>

</body>
</html>
