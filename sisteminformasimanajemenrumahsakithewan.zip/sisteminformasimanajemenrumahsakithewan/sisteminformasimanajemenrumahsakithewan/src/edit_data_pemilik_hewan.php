<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Data Pemilik Hewan</title>
<link rel="stylesheet" href="hewan.css">
<style>

    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f0f0f0;
        margin: 0;
        padding: 20px;
    }

    .form-container {
        max-width: 600px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 10px;
    }

    input[type="text"], input[type="number"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id_pemilik = $_GET['id'];

    $sql_pemilik = "SELECT ID_Pemilik, Nama_Pemilik, Alamat, Nomor_Telepon, ID_Dokter FROM pemilik_hewan WHERE ID_Pemilik = $id_pemilik";
    $result_pemilik = $conn->query($sql_pemilik);

    if ($result_pemilik->num_rows == 1) {
        $row = $result_pemilik->fetch_assoc();
        $nama_pemilik = $row['Nama_Pemilik'];
        $alamat = $row['Alamat'];
        $nomor_telepon = $row['Nomor_Telepon'];
        $id_dokter = $row['ID_Dokter'];
    } else {
        echo "Data pemilik hewan tidak ditemukan.";
        exit();
    }
} else {
    echo "Parameter ID tidak ditemukan.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_pemilik_baru = $_POST['nama_pemilik'];
    $alamat_baru = $_POST['alamat'];
    $nomor_telepon_baru = $_POST['nomor_telepon'];
    $id_dokter_baru = $_POST['id_dokter'];

    $sql_update = "UPDATE pemilik_hewan SET Nama_Pemilik = '$nama_pemilik_baru', Alamat = '$alamat_baru', Nomor_Telepon = '$nomor_telepon_baru', ID_Dokter = '$id_dokter_baru' WHERE ID_Pemilik = $id_pemilik";

    if ($conn->query($sql_update) === TRUE) {
        echo "<div class='form-container'>";
        echo "<h2>Data pemilik hewan berhasil diperbarui.</h2>";
        echo "<p><a href='index.php'>Kembali ke Daftar Pemilik Hewan</a></p>";
        echo "</div>";
    } else {
        echo "Error: " . $sql_update . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<div class="form-container">
    <h2>Edit Data Pemilik Hewan</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=$id_pemilik"; ?>">
        <label>Nama Pemilik:</label>
        <input type="text" name="nama_pemilik" value="<?php echo $nama_pemilik; ?>" required>

        <label>Alamat:</label>
        <input type="text" name="alamat" value="<?php echo $alamat; ?>" required>

        <label>Nomor Telepon:</label>
        <input type="text" name="nomor_telepon" value="<?php echo $nomor_telepon; ?>" required>

        <label>ID Dokter:</label>
        <input type="text" name="id_dokter" value="<?php echo $id_dokter; ?>" required>

        <input type="submit" value="Simpan Perubahan">
    </form>
</div>

</body>
</html>
