<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil ID dokter dari parameter URL
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id_dokter = $_GET['id'];

    // Query untuk mengambil data dokter berdasarkan ID
    $sql_select = "SELECT ID_Dokter, Nama_Dokter, Spesialisasi, Jadwal_Kerja FROM dokter_hewan WHERE ID_Dokter = $id_dokter";
    $result = $conn->query($sql_select);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_dokter = $row['ID_Dokter'];
        $nama_dokter = $row['Nama_Dokter'];
        $spesialisasi = $row['Spesialisasi'];
        $jadwal_kerja = $row['Jadwal_Kerja'];
    } else {
        echo "Data dokter hewan tidak ditemukan.";
        exit;
    }
}

// Proses update data dokter jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $id_dokter = $_POST['id_dokter'];
    $nama_dokter = $_POST['nama_dokter'];
    $spesialisasi = $_POST['spesialisasi'];
    $jadwal_kerja = $_POST['jadwal_kerja'];

    // Query untuk update data dokter berdasarkan ID
    $sql_update = "UPDATE dokter_hewan SET Nama_Dokter = '$nama_dokter', Spesialisasi = '$spesialisasi', Jadwal_Kerja = '$jadwal_kerja' WHERE ID_Dokter = $id_dokter";

    if ($conn->query($sql_update) === TRUE) {
        echo "Data dokter hewan berhasil diperbarui.";
        // Redirect ke halaman utama atau halaman detail jika diperlukan
        // header("Location: index.php");
    } else {
        echo "Error: " . $sql_update . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Data Dokter Hewan</title>
<link rel="stylesheet" href="hewan.css">
<style>
    /* Styles sesuai kebutuhan */
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f0f0f0;
        margin: 0;
        padding: 20px;
    }

    .form-container {
        max-width: 600px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 10px;
    }

    input[type="text"], select {
        width: 100%;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<div class="form-container">
    <h2>Edit Data Dokter Hewan</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="id_dokter" value="<?php echo $id_dokter; ?>">
        
        <label for="nama_dokter">Nama Dokter:</label>
        <input type="text" id="nama_dokter" name="nama_dokter" value="<?php echo $nama_dokter; ?>" required>
        
        <label for="spesialisasi">Spesialisasi:</label>
        <input type="text" id="spesialisasi" name="spesialisasi" value="<?php echo $spesialisasi; ?>" required>
        
        <label for="jadwal_kerja">Jadwal Kerja:</label>
        <input type="text" id="jadwal_kerja" name="jadwal_kerja" value="<?php echo $jadwal_kerja; ?>" required>
        
        <input type="submit" name="submit" value="Simpan Perubahan">
    </form>
</div>

</body>
</html>
