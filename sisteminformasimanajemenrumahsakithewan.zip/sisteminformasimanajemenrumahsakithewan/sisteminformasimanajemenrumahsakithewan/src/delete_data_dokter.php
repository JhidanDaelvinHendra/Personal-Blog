<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Data Dokter Hewan</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        .form-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .btn-container {
            margin-top: 20px;
            text-align: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #f44336;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #da190b;
        }
    </style>
</head>
<body>

<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id_dokter = $_GET['id'];

    $sql_delete = "DELETE FROM dokter_hewan WHERE ID_Dokter = ?";
    $stmt = $conn->prepare($sql_delete);
    $stmt->bind_param("i", $id_dokter);
    
    if ($stmt->execute()) {
        echo "<div class='form-container'>";
        echo "<h2>Data Dokter Hewan berhasil dihapus</h2>";
        echo "<div class='btn-container'>";
        echo "<a href='tampilkan_data_dokter_hewan.php' class='btn'>Kembali ke Daftar Dokter Hewan</a>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "<div class='form-container'>";
        echo "<h2>Gagal menghapus data dokter</h2>";
        echo "</div>";
    }
    
    $stmt->close();
} else {
    echo "<div class='form-container'>";
    echo "<h2>Parameter ID Dokter tidak ditemukan</h2>";
    echo "</div>";
}

$conn->close();
?>

</body>
</html>
