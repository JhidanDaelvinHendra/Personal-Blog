<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Dashboard</h2>
            <ul>
                <li><a href="#">Dashboard</a></li>
                <li><a href="#">Analytics</a></li>
                <li><a href="#">Reports</a></li>
                <li><a href="#">Users</a></li>
                <li><a href="#">Settings</a></li>
            </ul>
        </div>

        <!-- Main content -->
        <div class="main-content">
            <!-- Header -->
            <header>
                <h2>Welcome, Admin</h2>
                <div class="user">
                    <a href="#">Logout</a>
                </div>
            </header>

            <!-- Info Cards -->
            <div class="info-cards">
                <div class="card">
                    <h3>Total Users</h3>
                    <p>100</p>
                </div>
                <div class="card">
                    <h3>Active Users</h3>
                    <p>75</p>
                </div>
                <div class="card">
                    <h3>Inactive Users</h3>
                    <p>25</p>
                </div>
            </div>

            <!-- Charts -->
            <div class="charts">
                <div class="chart">
                    <!-- Chart here -->
                    <p>Chart 1</p>
                </div>
                <div class="chart">
                    <!-- Chart here -->
                    <p>Chart 2</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
