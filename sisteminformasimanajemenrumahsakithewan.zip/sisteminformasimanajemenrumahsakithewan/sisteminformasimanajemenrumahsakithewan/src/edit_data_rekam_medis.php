<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Rekam Medis</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        .form-container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group select {
            width: calc(100% - 16px);
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Edit Data Rekam Medis Hewan</h2>

    <?php
    // Ambil ID Rekam Medis dari URL
    $id_rekam_medis = isset($_GET['id']) ? $_GET['id'] : '';

    if ($id_rekam_medis == '') {
        die("ID Rekam Medis tidak ditemukan.");
    }

    // Konfigurasi koneksi database
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'sisteminformasimanajemenrumahsakithewan';

    // Buat koneksi
    $conn = new mysqli($host, $username, $password, $database);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil data rekam medis berdasarkan ID
    $sql = "SELECT * FROM rekam_medis WHERE ID_Rekam_Medis = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id_rekam_medis);
    $stmt->execute();
    $result = $stmt->get_result();

    // Cek apakah data ditemukan
    if ($result->num_rows == 0) {
        die("Data tidak ditemukan.");
    }

    $row = $result->fetch_assoc();
    ?>

    <!-- Form untuk mengedit data rekam medis -->
    <form action="update_data_rekam_medis.php" method="POST">
        <div class="form-group">
            <label for="id_rekam_medis">ID Rekam Medis:</label>
            <input type="text" id="id_rekam_medis" name="id_rekam_medis" value="<?php echo $row['ID_Rekam_Medis']; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="id_hewan">ID Hewan:</label>
            <input type="text" id="id_hewan" name="id_hewan" value="<?php echo $row['ID_Hewan']; ?>" required>
        </div>
        <div class="form-group">
            <label for="id_dokter">ID Dokter:</label>
            <input type="text" id="id_dokter" name="id_dokter" value="<?php echo $row['ID_Dokter']; ?>" required>
        </div>
        <div class="form-group">
            <label for="diagnosa">Diagnosa:</label>
            <select id="diagnosa" name="diagnosa" required>
                <option value="">Pilih Diagnosa</option>
                <option value="Komplikasi anestesi" <?php if($row['Diagnosa'] == 'Komplikasi anestesi') echo 'selected'; ?>>Komplikasi anestesi</option>
                <option value="Stres kronis" <?php if($row['Diagnosa'] == 'Stres kronis') echo 'selected'; ?>>Stres kronis</option>
                <option value="Agresi" <?php if($row['Diagnosa'] == 'Agresi') echo 'selected'; ?>>Agresi</option>
                <option value="Efek samping obat" <?php if($row['Diagnosa'] == 'Efek samping obat') echo 'selected'; ?>>Efek samping obat</option>
                <option value="Gingivitis" <?php if($row['Diagnosa'] == 'Gingivitis') echo 'selected'; ?>>Gingivitis</option>
                <option value="Alergi kulit" <?php if($row['Diagnosa'] == 'Alergi kulit') echo 'selected'; ?>>Alergi kulit</option>
                <option value="Trauma" <?php if($row['Diagnosa'] == 'Trauma') echo 'selected'; ?>>Trauma</option>
                <option value="Masalah kronis" <?php if($row['Diagnosa'] == 'Masalah kronis') echo 'selected'; ?>>Masalah kronis</option>
                <option value="Diabetes mellitus" <?php if($row['Diagnosa'] == 'Diabetes mellitus') echo 'selected'; ?>>Diabetes mellitus</option>
                <option value="Anemia" <?php if($row['Diagnosa'] == 'Anemia') echo 'selected'; ?>>Anemia</option>
                <option value="Infeksi bakteri" <?php if($row['Diagnosa'] == 'Infeksi bakteri') echo 'selected'; ?>>Infeksi bakteri</option>
                <option value="Obesitas" <?php if($row['Diagnosa'] == 'Obesitas') echo 'selected'; ?>>Obesitas</option>
                <option value="Kanker" <?php if($row['Diagnosa'] == 'Kanker') echo 'selected'; ?>>Kanker</option>
                <option value="Katarak" <?php if($row['Diagnosa'] == 'Katarak') echo 'selected'; ?>>Katarak</option>
                <option value="Biopsi" <?php if($row['Diagnosa'] == 'Biopsi') echo 'selected'; ?>>Biopsi</option>
                <option value="Penyakit Newcastle" <?php if($row['Diagnosa'] == 'Penyakit Newcastle') echo 'selected'; ?>>Penyakit Newcastle</option>
                <option value="Vaksinasi" <?php if($row['Diagnosa'] == 'Vaksinasi') echo 'selected'; ?>>Vaksinasi</option>
                <option value="Zoonosis" <?php if($row['Diagnosa'] == 'Zoonosis') echo 'selected'; ?>>Zoonosis</option>
                <option value="Fraktur tulang" <?php if($row['Diagnosa'] == 'Fraktur tulang') echo 'selected'; ?>>Fraktur tulang</option>
                <option value="Cedera otot" <?php if($row['Diagnosa'] == 'Cedera otot') echo 'selected'; ?>>Cedera otot</option>
                <option value="Hernia diskus intervertebralis (IVDH)" <?php if($row['Diagnosa'] == 'Hernia diskus intervertebralis (IVDH)') echo 'selected'; ?>>Hernia diskus intervertebralis (IVDH)</option>
                <option value="Infertilitas" <?php if($row['Diagnosa'] == 'Infertilitas') echo 'selected'; ?>>Infertilitas</option>
                <option value="Keracunan makanan atau bahan kimia" <?php if($row['Diagnosa'] == 'Keracunan makanan atau bahan kimia') echo 'selected'; ?>>Keracunan makanan atau bahan kimia</option>
                <option value="Penyakit spesifik pada hewan eksotis" <?php if($row['Diagnosa'] == 'Penyakit spesifik pada hewan eksotis') echo 'selected'; ?>>Penyakit spesifik pada hewan eksotis</option>
            </select>
        </div>
        <div class="form-group">
            <label for="tanggal_kunjungan">Tanggal Kunjungan:</label>
            <input type="date" id="tanggal_kunjungan" name="tanggal_kunjungan" value="<?php echo $row['Tanggal_Kunjungan']; ?>" required>
        </div>
        <div class="form-group">
            <button type="submit">Update Data</button>
        </div>
    </form>

    <?php
    // Menutup koneksi
    $conn->close();
    ?>
</div>

</body>
</html>
