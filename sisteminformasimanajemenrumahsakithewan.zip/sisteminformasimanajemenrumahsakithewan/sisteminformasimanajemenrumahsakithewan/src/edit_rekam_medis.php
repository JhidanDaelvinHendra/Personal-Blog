<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Rekam Medis</title>
    <link rel="stylesheet" href="rekam_medis.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        form {
            margin-top: 20px;
            text-align: left;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #333;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        $(document).ready(function() {
            $("#tanggal_kunjungan").datepicker({
                dateFormat: 'yy-mm-dd',
                changeYear: true,
                yearRange: "-100:+0"
            });
        });
    </script>
</head>
<body>

<div class="container">
    <h2>Edit Data Rekam Medis</h2>
    <?php

    $id_rekam_medis = $_GET['id'];


    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sisteminformasimanajemenrumahsakithewan";

    try {

        $pdo = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT id_rekam_medis, id_hewan, id_dokter, diagnosa, tanggal_kunjungan FROM rekam_medis WHERE id_rekam_medis = :id_rekam_medis");
        $stmt->bindParam(':id_rekam_medis', $id_rekam_medis);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {

            echo "<form method='post' action='proses_edit_rekam_medis.php'>";
            echo "<input type='hidden' name='id_rekam_medis' value='{$row['id_rekam_medis']}'>";
            echo "<div class='form-group'>";
            echo "<label for='id_hewan'>ID Hewan:</label>";
            echo "<input type='text' id='id_hewan' name='id_hewan' value='{$row['id_hewan']}' required>";
            echo "</div>";
            echo "<div class='form-group'>";
            echo "<label for='id_dokter'>ID Dokter:</label>";
            echo "<input type='text' id='id_dokter' name='id_dokter' value='{$row['id_dokter']}' required>";
            echo "</div>";
            echo "<div class='form-group'>";
            echo "<label for='diagnosa'>Diagnosa:</label>";
            echo "<input type='text' id='diagnosa' name='diagnosa' value='{$row['diagnosa']}' required>";
            echo "</div>";
            echo "<div class='form-group'>";
            echo "<label for='tanggal_kunjungan'>Tanggal Kunjungan:</label>";
            echo "<input type='text' id='tanggal_kunjungan' name='tanggal_kunjungan' value='{$row['tanggal_kunjungan']}' required>";
            echo "</div>";
            echo "<div class='form-group'>";
            echo "<button type='submit'>Simpan Perubahan</button>";
            echo "</div>";
            echo "</form>";
        } else {

            echo "<p>Data rekam medis tidak ditemukan.</p>";
        }

    } catch(PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    ?>
    <a href="tampil_rekam_medis.php">Kembali</a>
</div>

</body>
</html>
