<?php
session_start();

$users = [
    ['username' => 'adn', 'password' => 'adn', 'role' => 'admin'],
    ['username' => 'usr', 'password' => 'usr', 'role' => 'user']
    
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputUsername = $_POST["username"];
    $inputPassword = $_POST["password"];

    $user = array_filter($users, function ($u) use ($inputUsername) {
        return $u['username'] === $inputUsername;
    });

    if (!empty($user)) {
        $user = reset($user);

        if ($inputPassword === $user['password']) {

            $_SESSION['username'] = $inputUsername;
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header("Location: admin_dashboard.php");
                exit();
            } elseif ($user['role'] === 'user') {
                header("Location: user_dashboard.php");
                exit();
            }
        } else {
            header("Location: login.html?error=invalid");
            exit();
        }
    } else {
        header("Location: login.html?error=invalid");
        exit();
    }
}
?>
