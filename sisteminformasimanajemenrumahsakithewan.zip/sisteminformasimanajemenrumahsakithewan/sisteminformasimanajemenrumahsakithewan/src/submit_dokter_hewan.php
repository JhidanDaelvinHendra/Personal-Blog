<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Dokter Hewan</title>
    <link rel="stylesheet" href="dokter_hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .form-container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .data-table th, .data-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        .data-table th {
            background-color: #f2f2f2;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }

        .form-container h3 {
            margin-top: 0;
            text-align: center;
        }
        .form-container a {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #333;
        }
        .form-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h3>Data Dokter Hewan Berhasil Disimpan</h3>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id_dokter = $_POST['id_dokter'];
        $nama_dokter = $_POST['nama_dokter'];
        $spesialisasi = $_POST['spesialisasi'];
        $jadwal_kerja = $_POST['jadwal_kerja'];

        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "sisteminformasimanajemenrumahsakithewan";
        $conn = new mysqli($servername, $username, $password, $database);

        if ($conn->connect_error) {
            die("Koneksi gagal: " . $conn->connect_error);
        }

        $sql = "INSERT INTO dokter_hewan (id_dokter, nama_dokter, spesialisasi, jadwal_kerja)
                VALUES ('$id_dokter', '$nama_dokter', '$spesialisasi', '$jadwal_kerja')";

        if ($conn->query($sql) === TRUE) {
            echo "<table class='data-table'>";
            echo "<tr><th>ID Dokter</th><th>Nama Dokter</th><th>Spesialisasi</th><th>Jadwal Kerja</th></tr>";
            echo "<tr><td>$id_dokter</td><td>$nama_dokter</td><td>$spesialisasi</td><td>$jadwal_kerja</td></tr>";
            echo "</table>";
            echo "<br>";
            echo "<img src='NiawHospitalLogo.png' alt='Niaw Hospital Logo' style='max-width: 200px;'>";

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    } else {
        echo "<p>Akses tidak sah untuk halaman ini.</p>";
    }
    ?>
    <br><br>
    <a href="pemilikhewan.html">Kembali ke Form Pemilik Hewan</a>
    <a href="rekam_medis.html">Form Rekam Medis</a>
</div>

</body>
</html>
