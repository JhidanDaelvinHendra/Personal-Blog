<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="hewan.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .welcome {
            margin-bottom: 20px;
            text-align: center;
        }
        .logout {
            text-align: right;
            margin-bottom: 10px;
        }
        .logout a {
            color: #007BFF;
            text-decoration: none;
        }
        .logout a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Allo Apa Kabar, <?php echo $_SESSION['username']; ?>!</h2>
    <div class="hewan.html" style="text-align: center;">
    <a href="hewan.html">Cek Kesehatan Peliharaan Anda Disini Bersama Kami</a>
    </div>
</div>

</body>
</html>
