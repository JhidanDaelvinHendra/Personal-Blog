<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
} else {
    echo "Koneksi ke database berhasil.";
}

$conn->set_charset("utf8");

$conn->close();
?>
