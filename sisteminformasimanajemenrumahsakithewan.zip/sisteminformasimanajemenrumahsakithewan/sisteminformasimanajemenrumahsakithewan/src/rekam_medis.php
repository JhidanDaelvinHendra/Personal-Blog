<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "sisteminformasimanajemenrumahsakithewan";

$diagnosa = $_POST['diagnosa'];
$tanggal_kunjungan = $_POST['tanggal_kunjungan'];
$id_hewan = $_POST['id_hewan'];
$id_dokter = $_POST['id_dokter'];

try {
    $pdo = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt_check_hewan = $pdo->prepare("SELECT * FROM hewan WHERE ID_Hewan = :id_hewan");
    $stmt_check_hewan->bindParam(':id_hewan', $id_hewan, PDO::PARAM_INT);
    $stmt_check_hewan->execute();
    $hewan = $stmt_check_hewan->fetch(PDO::FETCH_ASSOC);

    if ($hewan) {

        $stmt_check_dokter = $pdo->prepare("SELECT COUNT(*) FROM dokter_hewan WHERE ID_Dokter = :id_dokter");
        $stmt_check_dokter->bindParam(':id_dokter', $id_dokter, PDO::PARAM_INT);
        $stmt_check_dokter->execute();
        $row_count_dokter = $stmt_check_dokter->fetchColumn();

        if ($row_count_dokter > 0) {

            $stmt = $pdo->prepare("INSERT INTO rekam_medis (ID_Hewan, ID_Dokter, diagnosa, tanggal_kunjungan) VALUES (:id_hewan, :id_dokter, :diagnosa, :tanggal_kunjungan)");
            $stmt->bindParam(':id_hewan', $id_hewan, PDO::PARAM_INT);
            $stmt->bindParam(':id_dokter', $id_dokter, PDO::PARAM_INT);
            $stmt->bindParam(':diagnosa', $diagnosa);
            $stmt->bindParam(':tanggal_kunjungan', $tanggal_kunjungan);

            $stmt->execute();

            header("Location: data_tersimpan.html");
            exit(); 

        } else {

            echo "Error: ID_Dokter '$id_dokter' tidak valid atau tidak ditemukan dalam database dokter_hewan.";
        }
    } else {

        echo "Error: ID_Hewan '$id_hewan' tidak valid atau tidak ditemukan dalam database hewan.";
    }

} catch(PDOException $e) {

    echo "Error: " . $e->getMessage();
}
?>
