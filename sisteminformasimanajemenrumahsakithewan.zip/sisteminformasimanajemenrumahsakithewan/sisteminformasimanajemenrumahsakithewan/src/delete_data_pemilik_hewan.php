<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id_pemilik = $_GET['id'];

    $sql_delete = "DELETE FROM pemilik_hewan WHERE ID_Pemilik = $id_pemilik";

    if ($conn->query($sql_delete) === TRUE) {
        echo "Data pemilik hewan berhasil dihapus.";
    } else {
        echo "Error: " . $sql_delete . "<br>" . $conn->error;
    }
} else {
    echo "Parameter ID tidak ditemukan.";
}

$conn->close();
?>
