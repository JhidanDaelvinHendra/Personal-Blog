<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Data Dokter Hewan</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Data Dokter Hewan</h2>

<?php
// Konfigurasi koneksi ke database
$servername = "localhost";  // Sesuaikan dengan host database Anda
$username = "root";     // Sesuaikan dengan username database Anda
$password = "";     // Sesuaikan dengan password database Anda
$dbname = "sisteminformasimanejemenrumahsakithewan";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil data dari tabel dokter_hewan
$sql = "SELECT ID_Dokter, Nama_Dokter, Spesialisasi, Jadwal_Kerja FROM dokter_hewan";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Tampilkan data dalam bentuk tabel
    echo "<table>";
    echo "<tr><th>ID Dokter</th><th>Nama Dokter</th><th>Spesialisasi</th><th>Jadwal Kerja</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["ID_Dokter"]."</td>";
        echo "<td>".$row["Nama_Dokter"]."</td>";
        echo "<td>".$row["Spesialisasi"]."</td>";
        echo "<td>".$row["Jadwal_Kerja"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data dokter hewan.";
}

// Tutup koneksi
$conn->close();
?>

</body>
</html>
