<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Data Hewan</title>
<link rel="stylesheet" href="hewan.css">
<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #f0f0f0;
        margin: 0;
        padding: 20px;
    }

    .form-container {
        max-width: 800px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    form {
        margin-top: 20px;
    }

    label {
        display: block;
        margin-bottom: 10px;
    }

    input[type="text"], input[type="number"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_hewan = $_GET['id'];

    $sql_get_hewan = "SELECT * FROM hewan WHERE ID_Hewan = '$id_hewan'";
    $result_get_hewan = $conn->query($sql_get_hewan);

    if ($result_get_hewan->num_rows == 1) {
        $row = $result_get_hewan->fetch_assoc();

        echo "<div class='form-container'>";
        echo "<h2>Edit Data Hewan</h2>";
        echo "<form action='update_data_hewan.php' method='POST'>";
        echo "<input type='hidden' name='id_hewan' value='".$row['ID_Hewan']."'>";
        echo "<label>Nama:</label>";
        echo "<input type='text' name='nama' value='".$row['Nama']."'>";
        echo "<label>Jenis:</label>";
        echo "<input type='text' name='jenis' value='".$row['Jenis']."'>";
        echo "<label>Ras:</label>";
        echo "<input type='text' name='ras' value='".$row['Ras']."'>";
        echo "<label>Umur:</label>";
        echo "<input type='number' name='umur' value='".$row['Umur']."'>";
        echo "<label>ID Pemilik:</label>";
        echo "<input type='text' name='id_pemilik' value='".$row['ID_Pemilik']."'>";
        echo "<input type='submit' value='Simpan'>";
        echo "</form>";
        echo "</div>";
    } else {
        echo "Data hewan tidak ditemukan.";
    }
} else {
    echo "ID hewan tidak diberikan.";
}

$conn->close();
?>

</body>
</html>
