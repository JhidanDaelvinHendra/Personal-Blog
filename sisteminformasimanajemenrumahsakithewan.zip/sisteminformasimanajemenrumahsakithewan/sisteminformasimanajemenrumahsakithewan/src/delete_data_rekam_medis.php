<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hapus Data Rekam Medis</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --color-primary: #BE0575;
            --color-secondary: #F62336;
            --color-tertiary: #FF6611;
            --color-quaternary: #FFEC4A;
            --color-quinary: #203FB6;
            --color-sixth: #008AFB;
        }

        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            color: #2b2b2b;
        }

        .form-container {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid #ccc;
            border-radius: 20px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: box-shadow 0.3s ease;
            text-align: center;
        }

        .form-container form {
            position: relative;
            z-index: 1;
        }

        .form-container h2 {
            color: var(--color-quaternary);
            margin-bottom: 20px;
            position: relative;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
            transition: color 0.3s ease;
        }

        .form-container h2::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 4px;
            background: linear-gradient(to right, var(--color-quaternary), var(--color-secondary));
            bottom: -5px;
            left: 0;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: scaleX(0);
        }

        .form-container h2:hover::before {
            opacity: 1;
            transform: scaleX(1);
        }

        .form-container h2:focus::before {
            opacity: 1;
            transform: scaleX(1);
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: var(--color-sixth);
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .back-link:hover {
            background-color: var(--color-primary);
        }

        @media (max-width: 600px) {
            .form-container {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Hapus Data Rekam Medis</h2>

    <?php
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'sisteminformasimanajemenrumahsakithewan';

    $conn = new mysqli($host, $username, $password, $database);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Ambil ID Rekam Medis dari URL
    $id_rekam_medis = isset($_GET['id']) ? $_GET['id'] : '';

    if ($id_rekam_medis == '') {
        echo "<p>ID Rekam Medis tidak ditemukan.</p>";
    } else {
        // Query untuk menghapus data rekam medis
        $sql = "DELETE FROM rekam_medis WHERE ID_Rekam_Medis = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $id_rekam_medis);

        // Eksekusi query dan periksa apakah berhasil
        if ($stmt->execute()) {
            echo "<p>Data rekam medis berhasil dihapus.</p>";
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }
    }

    // Menutup koneksi
    $conn->close();
    ?>

    <!-- Tambahkan link untuk kembali ke halaman utama atau daftar rekam medis -->
    <a class="back-link" href="tampilkan_data_rekam_medis.php">Kembali ke Daftar Rekam Medis</a>
</div>

</body>
</html>
