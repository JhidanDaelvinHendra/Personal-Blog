<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Sidebar</title>
    <!-- Import Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Import Google Fonts (Roboto) -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        /* Reset CSS untuk menghilangkan margin dan padding default */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif; /* Menggunakan font Roboto */
            background-color: #f0f0f0;
            color: #000; /* Warna teks tetap hitam */
            margin: 0;
            overflow-x: hidden; /* Menghindari scroll horizontal */
            transition: background-color 0.3s ease, color 0.3s ease; /* Transisi untuk mode malam */
        }

        .container {
            display: flex;
            width: 100%;
            height: 100vh; /* Mengisi seluruh tinggi viewport */
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            width: 220px; /* Lebar sedikit diperbesar */
            background-color: #f0f0f0; /* Warna latar belakang sidebar di mode siang */
            padding-top: 20px;
            color: #000; /* Warna teks hitam di mode siang */
            transition: all 0.3s ease;
            z-index: 1000; /* Memastikan sidebar berada di atas konten */
            overflow-y: auto; /* Menambahkan scroll di sidebar jika terlalu panjang */
            border-right: 2px solid #000; /* Garis tepi kanan hitam di mode siang */
        }

        .sidebar a {
            display: block;
            padding: 12px 20px; /* Padding diperbesar */
            color: #000; /* Warna teks hitam di mode siang */
            text-decoration: none;
            border-bottom: 1px solid #000; /* Garis bawah hitam di mode siang */
            transition: background-color 0.3s ease;
        }

        .sidebar a i {
            margin-right: 10px; /* Jarak ikon dari teks */
        }

        .sidebar a:hover {
            background-color: #ddd; /* Warna latar belakang hover sedikit lebih terang di mode siang */
        }

        .sidebar input[type="text"] {
            width: 90%;
            margin: 10px auto;
            padding: 8px;
            border: 1px solid #000;
            border-radius: 5px;
            background-color: #f0f0f0; /* Warna latar belakang input di mode siang */
            color: #000; /* Warna teks hitam di mode siang */
        }

        .sidebar .theme-switch {
            margin: 20px auto;
            text-align: center;
        }

        .sidebar .theme-switch label {
            display: inline-block;
            width: 60px;
            height: 34px;
            position: relative;
            cursor: pointer;
        }

        .sidebar .theme-switch label .slider {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            border-radius: 34px;
            transition: .4s;
        }

        .sidebar .theme-switch label .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            border-radius: 50%;
            transition: .4s;
        }

        .sidebar .theme-switch input:checked + .slider {
            background-color: #008AFB;
        }

        .sidebar .theme-switch input:checked + .slider:before {
            transform: translateX(26px);
        }

        .content {
            margin-left: 220px; /* Margin diperbesar */
            width: calc(100% - 220px); /* Mengambil sisa lebar setelah sidebar */
            padding: 20px;
            transition: margin-left 0.3s ease;
            background-color: #fff; /* Warna latar belakang konten tetap putih */
            border-radius: 10px; /* Sudut konten dibulatkan */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); /* Bayangan halus */
            transition: background-color 0.3s ease, color 0.3s ease; /* Transisi untuk mode malam */
        }

        .header {
            background-color: #BE0575; /* Warna latar belakang header */
            color: #fff;
            padding: 15px 20px; /* Padding diperbesar */
            margin-bottom: 20px;
            border-radius: 10px; /* Sudut header dibulatkan */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Bayangan header */
            text-align: center; /* Teks ditengah */
        }

        .header h1 {
            margin: 0;
            font-size: 24px; /* Ukuran teks diperbesar */
        }

        .data {
            background-color: #FFEC4A; /* Warna latar belakang data */
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Bayangan data yang lebih ringan */
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.5s ease, transform 0.5s ease, background-color 0.3s ease; /* Transisi untuk opacity, transform, dan background-color */
        }

        .data.show {
            opacity: 1;
            transform: translateY(0);
        }

        /* Responsif: tata letak sidebar dan konten untuk perangkat mobile */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                border-right: none; /* Hapus garis tepi kanan */
                border-bottom: 2px solid #008AFB; /* Tambah garis tepi bawah */
                padding-bottom: 20px; /* Padding bawah untuk link */
            }

            .sidebar a {
                padding: 12px 20px; /* Padding diperbesar */
            }

            .sidebar input[type="text"] {
                width: 90%;
                margin: 10px auto;
                padding: 8px;
            }

            .content {
                margin-left: 0;
                width: 100%;
                margin-top: 20px; /* Ruang atas untuk memisahkan header */
                padding: 15px; /* Padding diperbesar */
                border-radius: 0; /* Tidak ada border-radius */
                box-shadow: none; /* Tidak ada bayangan */
            }

            .header {
                border-radius: 0; /* Tidak ada border-radius */
                box-shadow: none; /* Tidak ada bayangan */
                padding: 12px 0; /* Padding diperkecil */
            }

            .header h1 {
                font-size: 22px; /* Ukuran teks diperkecil */
            }

            .data {
                margin-bottom: 15px; /* Margin bawah diperkecil */
                box-shadow: none; /* Tidak ada bayangan */
            }

            .sidebar .theme-switch {
                text-align: left;
                margin: 10px 20px;
            }
        }

        /* Mode Malam */
        body.dark-mode {
            background-color: #000;
            color: #fff;
        }

        .sidebar.dark-mode {
            background-color: #000;
            color: #fff;
            border-right: 2px solid #fff;
        }

        .sidebar.dark-mode a {
            color: #fff;
            border-bottom-color: #fff;
        }

        .sidebar.dark-mode input[type="text"] {
            background-color: #000;
            color: #fff;
            border-color: #fff;
        }

        .sidebar.dark-mode .theme-switch {
            color: #fff;
        }

        .content.dark-mode {
            background-color: #000;
            color: #fff;
        }

        /* Animasi Loading */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.8); /* Warna latar belakang semi-transparan */
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 999; /* Pastikan overlay berada di atas konten lain */
        }

        .loading-spinner {
            background-image: url('NiawHospitalLogo.png'); /* Gambar untuk animasi loading */
            background-size: contain;
            background-repeat: no-repeat;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite; /* Animasi putar-putar */
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <a href="#dokter_hewan"><i class="fas fa-cat"></i> Dokter Hewan</a>
            <a href="#hewan"><i class="fas fa-dog"></i> Hewan</a>
            <a href="#pemilik_hewan"><i class="fas fa-user-ninja"></i> Pemilik Hewan</a>
            <a href="#rekam_medis"><i class="fas fa-file-medical-alt"></i> Rekam Medis</a>
            <a href="#appointment"><i class="fas fa-calendar-check"></i> Janji Temu</a>
            <a href="#treatment"><i class="fas fa-notes-medical"></i> Perawatan</a>
            <div class="theme-switch">
                <label>
                    <input type="checkbox">
                    <span class="slider"></span>
                </label>
                <span style="margin-left: 10px;"></span>
            </div>
        </div>

        <div class="content">
            <div class="header">
                <h1>Admin Dashboard</h1>
            </div>

            <div id="dokter_hewan" class="data">
                <h2>Dokter Hewan</h2>
                <!-- Isi konten untuk dokter hewan -->
                <p><a href="tampilkan_data_dokter_hewan.php">Informasi Selengkapnya</a></p>
            </div>

            <div id="hewan" class="data">
                <h2>Hewan</h2>
                <!-- Isi konten untuk hewan -->
                <p><a href="tampilkan_data_hewan.php">Informasi Selengkapnya</a></p>
            </div>

            <div id="pemilik_hewan" class="data">
                <h2>Pemilik Hewan</h2>
                <!-- Isi konten untuk pemilik hewan -->
                <p><a href="tampilkan_data_pemilik_hewan.php">Informasi Selengkapnya</a></p>
            </div>

            <div id="rekam_medis" class="data">
                <h2>Rekam Medis</h2>
                <!-- Isi konten untuk rekam medis -->
                <p><a href="tampilkan_data_rekam_medis.php">Informasi Selengkapnya</a></p>
            </div>

            <div id="appointment" class="data">
                <h2>Janji Temu</h2>
                <!-- Isi konten untuk janji temu -->
                <p><a href="kontenjanjitemu.php">Informasi Selengkapnya</a></p>
            </div>

            <div id="treatment" class="data">
                <h2>Perawatan</h2>
                <!-- Isi konten untuk perawatan -->
                <p><a href="kontenperawatan.php">Informasi Selengkapnya</a></p>
            </div>
        </div>
    </div>

    <script>
        // JavaScript code here
        // Ambil semua link di sidebar
        const sidebarLinks = document.querySelectorAll('.sidebar a');

        // Tambahkan event listener untuk setiap link
        sidebarLinks.forEach(link => {
            link.addEventListener('click', smoothScroll);
        });

        // Fungsi untuk menggulir halaman secara smooth
        function smoothScroll(event) {
            event.preventDefault();
            const targetId = this.getAttribute('href').substring(1); // Ambil id target tanpa tanda #
            const targetElement = document.getElementById(targetId);
            
            // Tambahkan overlay loading
            const loadingOverlay = document.createElement('div');
            loadingOverlay.classList.add('loading-overlay');
            loadingOverlay.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loadingOverlay);

            // Gulir halaman ke posisi target dengan animasi
            targetElement.scrollIntoView({
                behavior: 'smooth'
            });

            // Tambahkan kelas 'show' untuk animasi konten
            setTimeout(() => {
                targetElement.classList.add('show');
                // Hapus overlay loading setelah konten dimuat
                document.body.removeChild(loadingOverlay);
            }, 300); // Sesuaikan dengan durasi animasi scroll
        }

        // Animasi tambahan untuk konten
        const dataSections = document.querySelectorAll('.data');

        dataSections.forEach(section => {
            section.addEventListener('mouseenter', () => {
                section.style.transform = 'scale(1.02)';
                section.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
            });

            section.addEventListener('mouseleave', () => {
                section.style.transform = 'scale(1)';
                section.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
            });
        });

        // Ambil elemen switch dan tambahkan event listener
        const themeSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
        themeSwitch.addEventListener('change', () => {
            document.body.classList.toggle('dark-mode');
            document.querySelectorAll('.sidebar, .sidebar a, .content').forEach(element => {
                element.classList.toggle('dark-mode');
            });
        });
    </script>
</body>
</html>
