<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sisteminformasimanajemenrumahsakithewan';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id_hewan = $_POST['id_hewan'];
$nama = $_POST['nama'];
$jenis = $_POST['jenis'];
$ras = $_POST['ras'];
$umur = $_POST['umur'];
$id_pemilik = $_POST['id_pemilik'];

$sql_update_hewan = "UPDATE hewan SET Nama='$nama', Jenis='$jenis', Ras='$ras', Umur=$umur, ID_Pemilik='$id_pemilik' WHERE ID_Hewan='$id_hewan'";

if ($conn->query($sql_update_hewan) === TRUE) {
    echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Data Hewan</title>
    <link rel="stylesheet" href="hewan.css"> <!-- Link to your external stylesheet -->
    <style>
        /* Paste the CSS provided */
    </style>
</head>
<body>

<div class="form-container">
    <h2>Data hewan berhasil diupdate</h2>
    <p style="text-align: center;">
        <a href="tampilkan_data_hewan.php">Kembali ke Data Hewan</a>
    </p>
</div>

</body>
</html>
HTML;
} else {
    echo "Error: " . $sql_update_hewan . "<br>" . $conn->error;
}

$conn->close();
?>
