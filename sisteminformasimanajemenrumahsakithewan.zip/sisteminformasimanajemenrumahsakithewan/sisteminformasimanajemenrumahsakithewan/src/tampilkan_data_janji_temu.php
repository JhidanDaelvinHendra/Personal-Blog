<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Sistem Informasi Rumah Sakit Hewan</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Data Dokter Hewan, Hewan, Pemilik Hewan, dan Rekam Medis</h2>

<?php
// Konfigurasi koneksi ke database
$servername = "localhost";  // Sesuaikan dengan host database Anda
$username = "username";     // Sesuaikan dengan username database Anda
$password = "password";     // Sesuaikan dengan password database Anda
$dbname = "sisteminformasimanajemenrumahsakithewan";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil data dokter_hewan
$sql_dokter = "SELECT ID_Dokter, Nama_Dokter, Spesialisasi, Jadwal_Kerja FROM dokter_hewan";
$result_dokter = $conn->query($sql_dokter);

// Query untuk mengambil data hewan
$sql_hewan = "SELECT ID_Hewan, Nama, Jenis, Ras, Umur, ID_Pemilik FROM hewan";
$result_hewan = $conn->query($sql_hewan);

// Query untuk mengambil data pemilik_hewan
$sql_pemilik = "SELECT ID_Pemilik, Nama_Pemilik, Alamat, Nomor_Telepon FROM pemilik_hewan";
$result_pemilik = $conn->query($sql_pemilik);

// Query untuk mengambil data rekam_medis
$sql_rekam_medis = "SELECT ID_Rekam_Medis, ID_Hewan, ID_Dokter, Diagnosa, Tanggal_Kunjungan FROM rekam_medis";
$result_rekam_medis = $conn->query($sql_rekam_medis);

// Tampilkan data dalam bentuk tabel
echo "<h3>Data Dokter Hewan</h3>";
if ($result_dokter->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID Dokter</th><th>Nama Dokter</th><th>Spesialisasi</th><th>Jadwal Kerja</th></tr>";
    while($row = $result_dokter->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["ID_Dokter"]."</td>";
        echo "<td>".$row["Nama_Dokter"]."</td>";
        echo "<td>".$row["Spesialisasi"]."</td>";
        echo "<td>".$row["Jadwal_Kerja"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data dokter hewan.";
}

echo "<h3>Data Hewan</h3>";
if ($result_hewan->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID Hewan</th><th>Nama</th><th>Jenis</th><th>Ras</th><th>Umur</th><th>ID Pemilik</th></tr>";
    while($row = $result_hewan->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["ID_Hewan"]."</td>";
        echo "<td>".$row["Nama"]."</td>";
        echo "<td>".$row["Jenis"]."</td>";
        echo "<td>".$row["Ras"]."</td>";
        echo "<td>".$row["Umur"]."</td>";
        echo "<td>".$row["ID_Pemilik"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data hewan.";
}

echo "<h3>Data Pemilik Hewan</h3>";
if ($result_pemilik->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID Pemilik</th><th>Nama Pemilik</th><th>Alamat</th><th>Nomor Telepon</th></tr>";
    while($row = $result_pemilik->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["ID_Pemilik"]."</td>";
        echo "<td>".$row["Nama_Pemilik"]."</td>";
        echo "<td>".$row["Alamat"]."</td>";
        echo "<td>".$row["Nomor_Telepon"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data pemilik hewan.";
}

echo "<h3>Data Rekam Medis</h3>";
if ($result_rekam_medis->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID Rekam Medis</th><th>ID Hewan</th><th>ID Dokter</th><th>Diagnosa</th><th>Tanggal Kunjungan</th></tr>";
    while($row = $result_rekam_medis->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["ID_Rekam_Medis"]."</td>";
        echo "<td>".$row["ID_Hewan"]."</td>";
        echo "<td>".$row["ID_Dokter"]."</td>";
        echo "<td>".$row["Diagnosa"]."</td>";
        echo "<td>".$row["Tanggal_Kunjungan"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Tidak ada data rekam medis.";
}

// Tutup koneksi
$conn->close();
?>

</body>
</html>
